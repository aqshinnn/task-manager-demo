function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var task = document.getElementById(data);
    ev.target.appendChild(task);
}

let taskId = 0;
function addTask() {
    const input = document.getElementById("taskInput");
    const taskText = input.value.trim();
    if (taskText === "") return;

    const task = document.createElement("div");
    task.className = "task";
    task.draggable = true;
    task.ondragstart = drag;
    task.id = "task-" + taskId++;
    task.innerText = taskText;

    document.getElementById("todo").appendChild(task);
    input.value = "";
}
